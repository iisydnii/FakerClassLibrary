﻿using System;
namespace FakerClassLibrary
{
    public enum StreetType
    {
        Road,
        Alley,
        Avenue,
        Boulevard,
        Byway,
        Court,
        Drive,
        Highway,
        Lane,
        Place,
        Route,
        Street,
        Way
    }
}
