﻿using System;
namespace FakerClassLibrary
{
    public enum FemaleFirstName
    {
        Emma,
        Olivia,
        Ava,
        Isabella,
        Sophia,
        Charlotte,
        Mia,
        Amelia,
        Harper,
        Sydni,
        Abigail,
        Emily,
        Elizabeth,
        Mila,
        Ella,
        Avery,
        Sofia,
        Camila,
        Aria,
        Scarlett
    }
}
