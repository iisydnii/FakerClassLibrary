﻿using System;
namespace FakerClassLibrary
{
    public enum MaleFirstName
    {
        Liam,
        Noah,
        William,
        James,
        Oliver,
        Benjamin,
        Elijah,
        Lucas,
        Mason,
        Logan,
        Alexander,
        Ethan,
        Jacob,
        Michael,
        Daniel,
        Henry,
        Jackson,
        Sebastian,
        Aiden,
        Matthew
    }
}
