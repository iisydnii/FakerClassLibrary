﻿using System;
namespace FakerClassLibrary
{
    public enum FemaleTitle
    {
        Mrs,
        Miss,
        Ms,
        Dr,
        Prof
    }
}
