﻿using System;
namespace FakerClassLibrary
{
    public enum MaleTitle
    {
        Mr,
        Dr,
        Prof
    }
}
