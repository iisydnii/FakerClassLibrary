﻿using System;

namespace FakerClassLibrary
{
    class Program
    {
        static void Main(string[] args)
        {

            Female one = new Female();
            
        }
    }
}
